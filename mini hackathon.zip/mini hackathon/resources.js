const params = new URLSearchParams(window.location.search);
const course = params.get("course");
const type = params.get("type");

const title = document.getElementById("resourceTitle");
const list = document.querySelector(".resource-list");

/* Fake data (simulating database rows) */
const resources = [
    {
        title: "Midterm Review Notes",
        desc: "Includes linked lists and recursion examples",
        file: "PDF",
        type: "notes"
    },
    {
        title: "Final Exam Practice",
        desc: "Problems similar to past finals",
        file: "PDF",
        type: "practice"
    },
    {
        title: "Assignment 2 Walkthrough",
        desc: "Detailed explanation of trees",
        file: "DOC",
        type: "notes"
    },
    {
        title: "Past Midterm Exam",
        desc: "Midterm from 2022",
        file: "PDF",
        type: "exams"
    }
];

/* Update page title */
const typeNames = {
    notes: "Notes",
    exams: "Previous Exams & Assignments",
    practice: "Practice Questions"
};

if (course && type) {
    title.innerText = `${course} — ${typeNames[type]}`;
}

/* Filter resources by type */
const filtered = resources.filter(r => r.type === type);

/* Clear existing content */
list.innerHTML = "";

/* Render filtered results */
if (filtered.length === 0) {
    list.innerHTML = "<p>No resources available yet.</p>";
} else {
    filtered.forEach(r => {
        const item = document.createElement("div");
        item.className = "resource-item";

        item.innerHTML = `
            <h3>${r.title}</h3>
            <p>${r.desc}</p>
            <span>📄 ${r.file}</span>
        `;

        list.appendChild(item);
    });
}
